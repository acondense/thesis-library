<?php

    // $host = "localhost";
    // $user = "root";
    // $password = "";
    // $dbName = "dbee";
    // $link = mysqli_connect($host, $user, $password, $dbName);
    // 
    // 

    $host = "localhost";
    $user = "pupee_admin";
    $password = "abc123";
    $dbName = "pupee_dbee";
    $link = mysqli_connect($host, $user, $password, $dbName);

?>